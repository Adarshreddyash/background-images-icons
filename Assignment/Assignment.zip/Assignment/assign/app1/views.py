from django.shortcuts import render

from rest_framework.views import APIView
from rest_framework.response import Response
from rest_framework import generics, filters
from rest_framework.parsers import JSONParser
from .models import Posts
from rest_framework import status
from .serializers import PostSerializer
from rest_framework import permissions
# Create your views here.

class ListPostsView(generics.ListAPIView):
    """
    Provides a get method handler.
    """
    queryset = Posts.objects.all().filter(isPublishd = True)        
    serializer_class = PostSerializer
