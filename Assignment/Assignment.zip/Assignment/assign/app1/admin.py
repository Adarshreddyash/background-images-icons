from django.contrib import admin

# Register your models here.

from .models import Posts

admin.register(Posts)(admin.ModelAdmin)
admin.site.site_header = "assignmnt dashboard"
