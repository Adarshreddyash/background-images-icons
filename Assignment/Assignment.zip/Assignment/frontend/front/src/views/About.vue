<template>
  <div class="about">
    <h1>After Logged in page</h1>
    <span v-for="post in posts" :key="post.id">
      <div class="card">
        <div class="container">
          <h4>
            <b>{{ post.title }}</b>
          </h4>
          <p>{{ post.description }}</p>
        </div>
      </div>
    </span>
  </div>
</template>
<script>
import axios from "axios";

export default {
  name: "About",
  data() {
    return {
      posts: [],
    };
  },

  mounted() {
    axios.get("http://127.0.0.1:8000/posts/").then(
      (response) => {
        this.posts = response.data.results;
        console.log("success");
      },
      (error) => {
        console.log(error);
      }
    );
  },
};
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped>
h3 {
  margin: 40px 0 0;
}
ul {
  list-style-type: none;
  padding: 0;
}
li {
  display: inline-block;
  margin: 0 10px;
}
a {
  color: #42b983;
}
.card {
  box-shadow: 0 4px 8px 0 rgba(0, 0, 0, 0.2);
  transition: 0.3s;
  width: 40%;
}

.card:hover {
  box-shadow: 0 8px 16px 0 rgba(0, 0, 0, 0.2);
}

.container {
  padding: 2px 16px;
}
</style>
