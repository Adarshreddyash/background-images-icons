<template>
  <div class="hello">
    <h1>{{ msg }}</h1>
    <form class="login" @submit.prevent="login">
      <h1>Sign in</h1>
      <label style="margin: 12px">Email</label>
      <input required v-model="email" placeholder="Name" />
      <label style="margin: 12px">Password</label>
      <input
        required
        v-model="password"
        type="password"
        placeholder="Password"
      />
      <hr />
      <button type="submit">Login</button>
    </form>
  </div>
</template>

<script>
import axios from "axios";

export default {
  name: "HelloWorld",
  data() {
    return {
      email: "",
      password: "",
    };
  },
  props: {
    msg: String,
  },
  methods: {
    login: function () {
      let email = this.email;
      let password = this.password;
      axios
        .post("http://127.0.0.1:8000/rest-auth/login/", {
          username: email,
          password: password,
        })
        .then(
          (response) => {
            console.log(response);

            this.$router.push("/about");
          },
          (error) => {
            console.log(error);
            alert("Wrong credentials");
          }
        );
    },
  },
};
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped>
h3 {
  margin: 40px 0 0;
}
ul {
  list-style-type: none;
  padding: 0;
}
li {
  display: inline-block;
  margin: 0 10px;
}
a {
  color: #42b983;
}
</style>
